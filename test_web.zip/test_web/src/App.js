import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Hello World! My name is Lee SungJin</p>
        <p>Testing....</p>
      </header>
    </div>
  );
}

export default App;
